import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { LoadingIcon } from './icons';
import Challenge from './challenge';

const Card = ({
  text,
  fetchCaptcha,
  submitResponse,
  verified,
  failed,
}) => {
  const { useState, useRef, useEffect } = React;
  const [key, setKey] = useState(Math.random());
  const [captcha, setCaptcha] = useState(false);
  const [loading, setLoading] = useState(false);
  const [title, setTitle] = useState('ยืนยันตัวตน');
  const isMounted = useRef(false);

  const receiveDataFromFlutter = (data) => {
    alert(data)
    setCaptcha(data)
  }

  const refreshCaptcha = async () => {
    if (verified || loading) {
      return;
    }
    // setLoading(true);
    // fetchCaptcha().then((newCaptcha) => {
    //   setTimeout(() => {
    //     if (!isMounted.current) return;
    //     setKey(Math.random());
    // let strCaptcha = ({ "code": 1000, "background": "iVBORw0KGgoAAAANSUhEUgAAAR8AAAChCAIAAABxgiyrAAALbUlEQVR4nOydX4hdVxXGT9MQLK1NQSaF0EAyTU0LxWnT2OKQRkEYRRGMRB9MHuyDVEqpFl8SpubBJjQvvtQgJAHjw6QPilEQLYz4YBMCjUlsBsHWpolQEZK8NK3BEjQjdQ1nbs49f/bZe621197n+5GHzJ1zz10P8+Nbe+197125eGSh4OPZU6cY76bAwelp94vPnntOshYffvHbNaM/fm3XfscnPr7h3zIV+fPkxLHYJfTjxNWd7Res0KoEaHB8bvb43GzsKsASnHYlF1y9ajYYXEVRfP3LV8YfhGBGQHblSXKCJdcWutTMZleKwUW4VG4zuIja+EpRsPxAdnVjWS0CgtkEdmVOk2CnL92hXsvg4LEr3baQSL3+dmoFMziRzw9kVwf220KiqTkk0CJGAXa18dDCttglgIRZGbsAQ+Tt0vG5WfeTHMqkOI4nnpw41nJiA9m1RK1ac/95JEYtnrQ3h5bpPFJklvbKYdeAwOpLGdgFgBSwa4hgHK8Dg115bBZ9/l8HYpegAZpDTRjs6vUWKbP84a7dsUsAuYHOcHCgLVQDdjUiPY6/f9Nr7PfEUF6Tzpqxm9zIrpVv8Ao2rlPlkXfeCt3OrnwQAIgL7NLAMabosnDHgBHQGcpy/6bX+naAHk/pxe4X98ndPIS0mkOXamGXICGSyAl24AcvCN0ZVIBdUoTrIZpgQAEeu1Lf8mLf7OISY2iCpdIcOtaJ7AJACtjVxq6Vb/S6fuLwjonDO3gDx/1uxsfxhy6vcrnMfny5V8g2kT84PZ3ogUOcgRJiXKfKI0/fe6P2iSeu7jT7fspe8iO7mLn7R/yfw8EYhjoDw0OXV7kkleNl6cJpV4qzjc7g6tscxsJIW+ghTO1TbPaHfatCdgE2QoLIvmAe9TDblVZ8DW3FJdoWhvd4lgXzqwTZ1Y395jB6W8i1fLIpmHcN/HalEl+9gstRMImRBtEy2HBUK90DUHEFC3l1keyyL5hQT/j+91+WuK3xg/O8c7/au8USLPB10Rm6YrM/zD64SvQFC39FKbssxxeGGYxIbFg13fPE1Z06jnG9kGB22RSsXa2P/eVCy2+txZdLcGWQWhWkBavcf+sZ/4mR7HuTrR2PqlWrYtTojx8+vLFyMfvHAXgzTLUIEoD3tNTiq8/Tf7aO/apJsJNbOj7F5LbFIwssxbVgRLBxtdqTqmTcsSbBJg7vkJgcjo807KgldJSp6QhiLSGalVKF0KSZxlTDQovorVbtlXFbRDtqGYGWSX07xsVXn2dRi8KtNt80souImGAhapW4JxjvudtKcJlSS/QMbq/4aqHyJUAh6yhHyijTs4tQduzg9PT4Vwd5qEW4CyZkV6da+pFloTN0R0EtggTTtktTMOpIK3Z5q0WMC9bkGItgpVoGvSJSsUvNq1Ei2EWIOlZZ6Y0KJmEXMe5YoGCkVrtX0ddXSdgVRa2YdhHsjjVNUEiwQLUIHcFIrcc2Lx+t2v3ivugujWPfrlhqxbeLYHGsfTKpY1dJRbNejr3z1rZRqYxj2a6IXhEm7Crx0Mx93P/QwjYdu/76qWWXzp5b3vvqdOyeO22dBXGEXbA81DJnVxPPnjrFsmn26Ctrw2/SbteoWk2cPffcY5tffu/6I4nqVMGgXRbUSsYuFljUIpoEc1ErSxgFyya4hvUOlD9/858s94FaxjGiFr5hiAd49fS9N1jiK5uekBhQdgkBtYhwMTJTC9kVBLyqEJJgQkef4jKgqQYRONv48OGNkKqTXo5xeWUtuJBdvYFaLpAwnY7lcSCjhcFlV0h8cU0dh8mhy6vk2j+bdg1xquEnCdQKJMuVVTtDtMtDFahlGZvBNVy7egkDtYAfQ1x3VWhZhsEr+5gNLswMi4pCj76y1tuoi++unlx3ja8ukDyw6xZ6qXXx3dXtj0C2gQO7fBj3quUyOCaH5bYQdvXG0avxp8CxATLcmaEHHmqxPBckCuxyJVwPCDY0YJcTXGJAsEEBu7rhVQKCDQfYBYAUsKsDiahBfA0E2AVSxfhmF+zqQC5kEF/hdH71Y3Swm5wz3349mU/MLjnyBPM3d0YE2QWAFMiu/Fnxt/dil+DEzU/eE7sEZpBdAEgBuxqRHjxgsJE9sKsR6VPtODWfPbALAClgF0gY41tesAsAKWAXAFLArjbkBg8YaXBhuTmEXQBIAbs6kAgZBBcvZuMLdgEgBezqhjdqEFzDwbRd80fPxy5hCS4loJYQNptDK2fkm0SqfXzmqSn5iqpMrrsWeDIQaolycssVa+9WjmyXXzqVz1LWLEQwqDVA4tjF1fLpa0aS9HIMXqlhLb4irLskVlPKK7TJdddcnHG8DDBiagGmml2iDtDNNXvFijn4/i4j2EkwJbvUskXfsRKoBSpodIb6g3U7o3wQBSP9obhdsf7QIdjAsSCYrF1x/8Qh2MA5ueVKXMcE7bLwx22hBhCXiIJJTTXs/FnPHz0fZchR4Wfvf7rlt9+6+0+KtQyOWFNEkeyyoxZhrR6gj3KXSC9n+hQvALzoCFa+Cn9naDMojPSHIDrlnz57rziurpUz8gAoQzKwONYUicx22QwugjG+9vz8hf5P+kLbDYtbbvjSN/Z5VNXOB2/f/vEH/st+29QJibLOPpPTLstqEQPpD/8+d8fS/x4oyCv6qfzPKFCOaFJl65k13qs1dIb5sCxVH0rloFktIYMQ2JUDfl5VIM3gGCNsE3n7bSGRSp3usKhVUts9Aj+QXQnD61UJQowL7CanipBaJQixcHjsSqvdSqvaWqTVIiBYIMiu9NBRi5AW7Mz606L3jwvWXYmhqRbBsg3dYlH5q83FTFEUe7fvoR9/+KuXAl80OrArJfTVIrwFC4mmDDSDXckQSy2ir2CMLR9plqJjsAtwIreOSjHKMNVIg7jBRXROOHRGFKVm9mGwK8UBd1o1W1CLaBLszPrTmtO/vdv3JOEYg12WT53/+rMbax+3XHNyxJqq2xcsw3VXxajRH7/6xwsxKgrCTnARlfFG3A2rvdv3WF6GZWVXU1JVLkjRMYMY2Qi2PFHMZ6rRqZbHlelybEb2Q+2NqFVis0vMJLv6CvPMxes/mbxTrBw2XNrCJpE+evzSR/+5cN+N8sGN/1gVXtUHb99erA+/DTMGu8Qc7PLLolQEa8IvnUrTWDQD7STfGYa0ec9cvM5aiwbHZq7Rv8D7XLjvBv1jqssE1vpDHrsw4FaARapxMnPMlGBpZ1f4fCKV+JKeUkAwCXJYd+WNtFclJBjWY4ywZReaQwnU1CrJI8SMxFfanWHe7L8S5w/dRbBNv/+MSi3+WBAs4c6Qa1PY5mieUa2pqU/0f073JfRWYtACZ3YpN4dcB5ryVgtEhDm7Zp6aSuvNHQa563N7uW61fsN3Au+wc3517eM//eX3Au+sQPTTG1h32YJRLRb0xyo5wW8XhofeWFOLSFqwuLONhKcatPQKnG34Lbokvl8Ly638EOkMEV8eWFYr6fiKyG2LRxaEbq023vCOrzK4fnfuUvuVX9q8we8lHLGsVkk54fjujx9sv3Jq7RdVKnIl1mxDcKqhlmB+o3mDg3iQGbIzQ7OCmVIrieBCf+iB+ETeoGCm1EqOzrYQlGjsd2kK1u7Ym7M335y9qVMMAEoTeRJMYc5xYH6yKJb9eXD/CuM6pdIWEmgOe6G63yXq2P+9qmJcLZA3EU5CSTSKtWoBEBfB/S4XAnOMS9RY+11ptYUlp7/yRPsF1va7Ym15RT4JVerRSzOcBQG9iLWbbOWcYa0w80fPQySQLlbsqkVNLemDTmCY4P1dAEgBuwCQAnYBIAXsikai4/iiKB7/zeuxS0gD2BWN2TWpfupt534XIGAXyJyIHwsFuwCQAnYBIAXsAjmDTwsFIE9Mn4QCNjF4BL6W6F9S/r8AAAD//yGvuQFrKmR+AAAAAElFTkSuQmCC", "slider": "iVBORw0KGgoAAAANSUhEUgAAADwAAAChCAYAAACbBNzvAAAB4ElEQVR4nOzbPU46QQBA8eEfmn9l4QW8gHewsieWWhkvYWPhCTyApd7AymvYWnAFK8s1kCxZDaAD88G8fa/BaHT3x3xJlH9hZAmmJ5ieYHqC6QmmJ5ieYHqC6QmmJ5ieYHqC6QmmJ5ieYHqC6QmmJ5ieYHqC6QmmJ5ieYHqC6QmmJ5ieYHqC6QmmJ5ieYHqC6QmmJ5ieYHqC6U27rutq30TJxjfCq48e36reSPZuTpcPoxthwfQE0xNMTzA9wfQE0xNMTzA9wfQE0xNMTzA9wfQEz5/+17mTQq3+ejiEbkOfXH3mv6uMTWO/YfhktIjfaw0v8K0tgSSbVkvoZLt0K6Od/Fg6dHSWc/iQ0dl+8aiNvpvdrv38pP8/rfnZe5YL5zq6NoE2dX/8snyMPodjW4x0KnQscl3ZwSEBOgW0rwh4l1IihxV7tRSzieXChtIj/NvUzgntO5jXwyWwoQZ43dQuhQ21N62S0L5qU7oGNgxH+Pn849sXLl+Psl10Oa1n2X781jZO6eETkBNfuj+tYRI+eg0v8D+nf0vtvGm1it5rl25xtJMcSy2hk53Dsejri4dUl45q4jvTjNXoRlgwPcH0BNMTTE8wPcH0BNMTTE8wPcH0BNMTTE8wva8AAAD//x00XN4vxyIhAAAAAElFTkSuQmCC", "left": 159 })
    // setCaptcha(strCaptcha);
    //     setLoading(false);
    //   }, 300);
    // });
  };
  const completeCaptcha = (response, trail, left) => {
    const data = {
      action: "completeCaptcha",
      data: {
        response: response, trail: trail, left: left
      }
    }
    RecaptchaFlutterChannel.postMessage(data);
  }
  // new Promise((resolve) => {
  //   submitResponse(response, trail, left).then((verified) => {
  //     if (verified) {
  //       resolve(true);
  //     } else {
  //       refreshCaptcha();
  //       resolve(false);
  //     }
  //   });
  // });

  useEffect(() => {
    isMounted.current = true;
    // refreshCaptcha();

    // alert('first');
    // window.addEventListener('UpdateCaptcha', (event) => {
    //   const data = JSON.parse(event);
    //   receiveDataFromFlutter(data);
    // });
    return () => {
      isMounted.current = false;
    };
  }, []);

  useEffect(() => {
    const handleMessageFromFlutter = (event) => {
      console.log('Received message from Flutter:', event.data);
      // Handle the received message here
      alert(event.data)
      try {
        setCaptcha(JSON.parse(event.data))
      } catch (e) {
        RecaptchaFlutterChannel.postMessage(JSON.stringify({ action: "log", data: event }))
        RecaptchaFlutterChannel.postMessage(JSON.stringify({ action: "log", data: e.message }))
      }
    };

    window.addEventListener('message', handleMessageFromFlutter);

    return () => {
      window.removeEventListener('message', handleMessageFromFlutter);
    };
  }, []);

  const closeCaptcha = () => RecaptchaFlutterChannel.postMessage(JSON.stringify({ action: "close", data: null }))

  return (
    <div>
      <div className="header">
        <div className="title">{title}</div>
      </div>
      <div className="header">
        <div className="icon-close" onClick={() => closeCaptcha()}>
          <svg
            width="24"
            height="24"
            viewBox="0 0 24 24"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              fillRule="evenodd"
              clipRule="evenodd"
              d="M4.6129 3.2097C4.22061 2.90468 3.65338 2.93241 3.29289 3.29289C2.90237 3.68342 2.90237 4.31658 3.29289 4.70711L10.5858 12L3.29289 19.2929L3.2097 19.3871C2.90468 19.7794 2.93241 20.3466 3.29289 20.7071C3.68342 21.0976 4.31658 21.0976 4.70711 20.7071L12 13.4142L19.2929 20.7071L19.3871 20.7903C19.7794 21.0953 20.3466 21.0676 20.7071 20.7071C21.0976 20.3166 21.0976 19.6834 20.7071 19.2929L13.4142 12L20.7071 4.70711L20.7903 4.6129C21.0953 4.22061 21.0676 3.65338 20.7071 3.29289C20.3166 2.90237 19.6834 2.90237 19.2929 3.29289L12 10.5858L4.70711 3.29289L4.6129 3.2097Z"
              fill="#212121"
            />
          </svg>
        </div>
      </div>
      <div className="container-fluid">
        <div className="form-row">
          <div className="col-12">
            <div className="slidercaptcha card">
              <div className="card-header">
                <span>{text.title}</span>
                <div className="refreshIcon" onClick={refreshCaptcha}>
                  <svg
                    width="20"
                    height="20"
                    viewBox="0 0 20 20"
                    fill="none"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      fillRule="evenodd"
                      clipRule="evenodd"
                      d="M1.66651 11.8021V11.6666C1.66651 11.2393 1.98821 10.887 2.40266 10.8389L2.49984 10.8333H6.66651C7.12675 10.8333 7.49985 11.2064 7.49985 11.6666C7.49985 12.094 7.17814 12.4462 6.7637 12.4943L6.66651 12.4999H4.50541L6.4181 14.2349C7.78891 15.5586 9.77394 16.1127 11.6722 15.6982C13.5654 15.2848 15.1014 13.9671 15.7443 12.2136C15.9028 11.7815 16.3815 11.5596 16.8136 11.7181C17.2457 11.8765 17.4676 12.3552 17.3091 12.7873C16.4682 15.0809 14.4729 16.7925 12.0277 17.3265C9.67172 17.841 7.20998 17.1942 5.46374 15.6235L5.27942 15.4516L3.33309 13.6865L3.33318 15.8333C3.33318 16.2606 3.01148 16.6129 2.59703 16.661L2.49984 16.6666C2.07248 16.6666 1.72026 16.3449 1.67212 15.9305L1.66651 15.8333V11.8091C1.6665 11.8068 1.6665 11.8044 1.66651 11.8021ZM14.7203 4.54825L14.5359 4.37643L14.3462 4.21169C12.614 2.76099 10.2438 2.17726 7.97196 2.67338C5.5268 3.20735 3.53148 4.919 2.69055 7.21257C2.53212 7.64468 2.75398 8.12341 3.18609 8.28184C3.61819 8.44027 4.09692 8.21841 4.25535 7.7863C4.89827 6.03279 6.43433 4.71511 8.32754 4.30167C10.2257 3.88715 12.2108 4.44131 13.5816 5.765L15.4943 7.49995H13.3332L13.236 7.50555C12.8215 7.55369 12.4998 7.90592 12.4998 8.33328C12.4998 8.79352 12.8729 9.16661 13.3332 9.16661H17.4998L17.597 9.16101C18.0115 9.11287 18.3332 8.76064 18.3332 8.33328V8.19654C18.3332 8.19505 18.3332 8.19356 18.3332 8.19206V4.16661L18.3276 4.06943C18.2794 3.65498 17.9272 3.33328 17.4998 3.33328L17.4027 3.33889C16.9882 3.38702 16.6665 3.73925 16.6665 4.16661L16.6664 6.31323L14.7203 4.54825Z"
                      fill="#838383"
                    />
                  </svg>
                </div>
              </div>
              <div className="card-body">
                <Challenge
                  key={key}
                  text={text}
                  captcha={captcha}
                  loaded={!loading}
                  verified={verified}
                  failed={failed}
                  completeCaptcha={completeCaptcha}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="scaptcha-container">
        <div className="scaptcha-card-container scaptcha-card-element">
          <span>{text.title}</span>
        </div>
      </div>
    </div>
  );
};

// Card.propTypes = {
//   fetchCaptcha: PropTypes.func.isRequired,
//   submitResponse: PropTypes.func.isRequired,
//   text: PropTypes.shape({
//     anchor: PropTypes.string,
//     challenge: PropTypes.string,
//   }).isRequired,
// };

export default Card;
