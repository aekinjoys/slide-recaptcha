import SliderCaptcha from './slider-captcha';

export default SliderCaptcha;
