import React, { useState } from 'react';
import PropTypes from 'prop-types';
import Anchor from './anchor';
import Theme from './theme';
import Card from './card';


const SliderCaptcha = ({
  callback = () => { },
  create = "captcha/create",
  verify = "captcha/verify",
  text = {
    title: "กรุณาเลื่อนลูกศรเพื่อต่อรูปให้สมบูรณ์",
    loading: "กำลังโหลด",
    challenge: "เลื่อนไปทางขวา",
    failed: "กรุณาลองใหม่อีกครั้ง",
  },
}) => {
  const { useState } = React;
  const [verified, setVerified] = useState(false);
  const [failed, setFailed] = useState(false);

  const test = () => {
    alert('call success');
  }

  const fetchCaptcha = (create) => () =>
    (create instanceof Function)
      ? create() // Use provided promise for getting background and slider
      : fetch(create, {
        // Use create as API URL for fetch
        method: 'GET',
        credentials: 'include',
      }).then((message) => message.json());

  const fetchVerification = (verify) => (response, trail) =>
    (verify instanceof Function)
      ? verify(response, trail) // Use provided promise for verifying captcha
      : fetch(verify, {
        // Verification API URL provided instead
        method: 'POST',
        credentials: 'include',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          response,
          trail,
        }),
      }).then((message) => message.json());

  const submitRequest = () =>
    new Promise(async (resolve) => {
      return fetchCaptcha(create)().then((result) => {
        if (result.code !== 1000) {
          resolve(false);
        } else {
          resolve(result);
        }
      });
    });

  const submitResponse = (response, trail, left) =>
    new Promise((resolve) => {
      fetchVerification(verify)(response, trail, left).then((result) => {
        if (result.code !== 1000) {
          setFailed(true);
          resolve(false);
        } else {
          setTimeout(() => {
            callback(result);
            setVerified(true);
          }, 500);
          resolve(true);
        }
      });
    });
  return (
    <div className="scaptcha-container">
      <Card
        fetchCaptcha={submitRequest}
        submitResponse={submitResponse}
        text={text}
        verified={verified}
        failed={failed}
      />
    </div>
  );
};

// SliderCaptcha.propTypes = {
//   callback: PropTypes.func,
//   create: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
//   verify: PropTypes.oneOfType([PropTypes.string, PropTypes.func]),
//   variant: PropTypes.string,
//   text: PropTypes.shape({
//     anchor: PropTypes.string,
//     challenge: PropTypes.string,
//   }),
// };

// SliderCaptcha.defaultProps = {
//   callback: (token) => console.log(token), // eslint-disable-line no-console
//   create: 'captcha/create',
//   verify: 'captcha/verify',
//   text: {
//     anchor: 'I am human',
//     challenge: 'Slide to finish the puzzle',
//   },
// };

export default SliderCaptcha;
